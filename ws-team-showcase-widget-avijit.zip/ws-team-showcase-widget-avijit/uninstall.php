<?php
/**
 * Uninstall cleanup for WS Team Showcase Widget.
 *
 * Removes plugin-created Team Showcase posts and matching ACF field group records
 * when the plugin is deleted from WordPress admin.
 */

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

/**
 * Delete an ACF field and all nested sub-fields.
 */
function ws_tsw_delete_acf_field_tree( int $parent_id ): void {
	$field_ids = get_posts(
		[
			'post_type'      => 'acf-field',
			'post_status'    => 'any',
			'post_parent'    => $parent_id,
			'fields'         => 'ids',
			'posts_per_page' => -1,
			'no_found_rows'  => true,
		]
	);

	foreach ( $field_ids as $field_id ) {
		ws_tsw_delete_acf_field_tree( (int) $field_id );
		wp_delete_post( (int) $field_id, true );
	}
}

$post_type = 'ws_team_showcase';

$team_showcase_ids = get_posts(
	[
		'post_type'      => $post_type,
		'post_status'    => 'any',
		'fields'         => 'ids',
		'posts_per_page' => -1,
		'no_found_rows'  => true,
	]
);

foreach ( $team_showcase_ids as $post_id ) {
	wp_delete_post( (int) $post_id, true );
}

// Local ACF groups do not create database rows, but this removes matching rows
// if the group was previously saved/synced into ACF's database tables.
$acf_group_ids = get_posts(
	[
		'post_type'      => 'acf-field-group',
		'post_status'    => 'any',
		'fields'         => 'ids',
		'posts_per_page' => -1,
		'no_found_rows'  => true,
		'meta_query'     => [
			[
				'key'     => '_ws_team_showcase_widget',
				'value'   => '1',
				'compare' => '=',
			],
		],
	]
);

$legacy_group_ids = get_posts(
	[
		'post_type'      => 'acf-field-group',
		'post_status'    => 'any',
		'fields'         => 'ids',
		'posts_per_page' => -1,
		'no_found_rows'  => true,
		'name'           => 'group_ws_team_showcase_members',
	]
);

$acf_group_ids = array_unique( array_merge( $acf_group_ids, $legacy_group_ids ) );

foreach ( $acf_group_ids as $group_id ) {
	ws_tsw_delete_acf_field_tree( (int) $group_id );
	wp_delete_post( (int) $group_id, true );
}

delete_option( 'ws_team_showcase_widget_version' );
