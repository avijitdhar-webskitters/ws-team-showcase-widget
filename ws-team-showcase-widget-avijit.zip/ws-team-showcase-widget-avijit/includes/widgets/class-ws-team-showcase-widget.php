<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use Elementor\Controls_Manager;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Typography;
use Elementor\Icons_Manager;
use Elementor\Repeater;
use Elementor\Widget_Base;

class WS_Team_Showcase_Widget extends Widget_Base {
	public function get_name(): string {
		return 'ws_team_showcase';
	}

	public function get_title(): string {
		return esc_html__( 'WS Team Showcase', 'ws-team-showcase-widget' );
	}

	public function get_icon(): string {
		return 'eicon-person';
	}

	public function get_categories(): array {
		return [ 'basic' ];
	}

	public function get_style_depends(): array {
		return [ 'ws-team-showcase' ];
	}

	public function get_script_depends(): array {
		return [ 'ws-team-showcase' ];
	}

	protected function register_controls(): void {
		$this->register_content_controls();
		$this->register_grid_controls();
		$this->register_layout_controls();
		$this->register_style_controls();
	}

	private function register_content_controls(): void {
		$this->start_controls_section(
			'section_members',
			[ 'label' => esc_html__( 'Team Members', 'ws-team-showcase-widget' ) ]
		);

		$this->add_control(
			'data_source',
			[
				'label'   => esc_html__( 'Data Source', 'ws-team-showcase-widget' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'manual',
				'options' => [
					'manual'       => esc_html__( 'Manual Repeater', 'ws-team-showcase-widget' ),
					'acf_repeater' => esc_html__( 'ACF Repeater', 'ws-team-showcase-widget' ),
				],
			]
		);

		$this->add_control(
			'acf_showcase_id',
			[
				'label'       => esc_html__( 'ACF Team Showcase', 'ws-team-showcase-widget' ),
				'type'        => Controls_Manager::SELECT2,
				'label_block' => true,
				'options'     => $this->get_acf_showcase_options(),
				'description' => esc_html__( 'Create entries under Team Showcases, then select the showcase post here.', 'ws-team-showcase-widget' ),
				'condition'   => [
					'data_source' => 'acf_repeater',
				],
			]
		);

		$member = new Repeater();

		$member->add_control(
			'name',
			[
				'label'       => esc_html__( 'Name', 'ws-team-showcase-widget' ),
				'type'        => Controls_Manager::TEXT,
				'default'     => esc_html__( 'Alex Morgan', 'ws-team-showcase-widget' ),
				'label_block' => true,
			]
		);

		$member->add_control(
			'designation',
			[
				'label'   => esc_html__( 'Designation', 'ws-team-showcase-widget' ),
				'type'    => Controls_Manager::TEXT,
				'default' => esc_html__( 'Creative Director', 'ws-team-showcase-widget' ),
			]
		);

		$member->add_control(
			'department',
			[
				'label'   => esc_html__( 'Department', 'ws-team-showcase-widget' ),
				'type'    => Controls_Manager::TEXT,
				'default' => esc_html__( 'Design', 'ws-team-showcase-widget' ),
			]
		);

		$member->add_control(
			'bio',
			[
				'label'   => esc_html__( 'Short Bio', 'ws-team-showcase-widget' ),
				'type'    => Controls_Manager::TEXTAREA,
				'default' => esc_html__( 'Leads cross-functional projects and helps teams ship polished client experiences.', 'ws-team-showcase-widget' ),
			]
		);

		$member->add_control(
			'image',
			[
				'label' => esc_html__( 'Profile Image', 'ws-team-showcase-widget' ),
				'type'  => Controls_Manager::MEDIA,
			]
		);

		$member->add_control(
			'social_links',
			[
				'label'       => esc_html__( 'Social Links', 'ws-team-showcase-widget' ),
				'type'        => Controls_Manager::TEXTAREA,
				'placeholder' => "LinkedIn|https://linkedin.com/in/example\nX|https://x.com/example",
				'description' => esc_html__( 'Add one social link per line using Label|URL.', 'ws-team-showcase-widget' ),
			]
		);

		$member->add_control(
			'experience',
			[
				'label'   => esc_html__( 'Experience', 'ws-team-showcase-widget' ),
				'type'    => Controls_Manager::TEXT,
				'default' => esc_html__( '8+ years experience', 'ws-team-showcase-widget' ),
			]
		);

		$member->add_control(
			'button_heading',
			[
				'label'     => esc_html__( 'Button', 'ws-team-showcase-widget' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$member->add_control(
			'button_type',
			[
				'label'   => esc_html__( 'Type', 'ws-team-showcase-widget' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'default',
				'options' => [
					'default' => esc_html__( 'Default', 'ws-team-showcase-widget' ),
					'info'    => esc_html__( 'Info', 'ws-team-showcase-widget' ),
					'success' => esc_html__( 'Success', 'ws-team-showcase-widget' ),
					'warning' => esc_html__( 'Warning', 'ws-team-showcase-widget' ),
					'danger'  => esc_html__( 'Danger', 'ws-team-showcase-widget' ),
				],
			]
		);

		$member->add_control(
			'button_text',
			[
				'label'   => esc_html__( 'Text', 'ws-team-showcase-widget' ),
				'type'    => Controls_Manager::TEXT,
				'default' => esc_html__( 'View Profile', 'ws-team-showcase-widget' ),
			]
		);

		$member->add_control(
			'button_url',
			[
				'label'       => esc_html__( 'Link', 'ws-team-showcase-widget' ),
				'type'        => Controls_Manager::URL,
				'placeholder' => 'https://example.com',
			]
		);

		$member->add_control(
			'button_icon',
			[
				'label' => esc_html__( 'Icon', 'ws-team-showcase-widget' ),
				'type'  => Controls_Manager::ICONS,
			]
		);

		$member->add_control(
			'button_icon_position',
			[
				'label'   => esc_html__( 'Icon Position', 'ws-team-showcase-widget' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'before',
				'options' => [
					'before' => esc_html__( 'Before', 'ws-team-showcase-widget' ),
					'after'  => esc_html__( 'After', 'ws-team-showcase-widget' ),
				],
				'condition' => [
					'button_icon[value]!' => '',
				],
			]
		);

		$member->add_control(
			'button_icon_spacing',
			[
				'label'      => esc_html__( 'Icon Spacing', 'ws-team-showcase-widget' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],
				'range'      => [
					'px' => [ 'min' => 0, 'max' => 40 ],
				],
				'default'    => [ 'size' => 8, 'unit' => 'px' ],
				'condition'  => [
					'button_icon[value]!' => '',
				],
			]
		);

		$member->add_control(
			'button_id',
			[
				'label'       => esc_html__( 'Button ID', 'ws-team-showcase-widget' ),
				'type'        => Controls_Manager::TEXT,
				'description' => esc_html__( 'Add a unique ID without #.', 'ws-team-showcase-widget' ),
			]
		);

		$this->add_control(
			'members',
			[
				'label'       => esc_html__( 'Members', 'ws-team-showcase-widget' ),
				'type'        => Controls_Manager::REPEATER,
				'fields'      => $member->get_controls(),
				'default'     => $this->get_default_members(),
				'title_field' => '{{{ name }}} - {{{ department }}}',
				'condition'   => [
					'data_source' => 'manual',
				],
			]
		);

		$this->end_controls_section();
	}

	private function register_grid_controls(): void {
		$this->start_controls_section(
			'section_grid_settings',
			[ 'label' => esc_html__( 'Grid Settings', 'ws-team-showcase-widget' ) ]
		);

		$this->add_control(
			'grid_columns_desktop',
			[
				'label'       => esc_html__( 'Desktop Cards Per Row', 'ws-team-showcase-widget' ),
				'type'      => Controls_Manager::SELECT,
				'default'   => '4',
				'label_block' => true,
				'options'   => [
					'1' => '1',
					'2' => '2',
					'3' => '3',
					'4' => '4',
					'5' => '5',
					'6' => '6',
				],
			]
		);

		$this->add_control(
			'grid_columns_tablet',
			[
				'label'       => esc_html__( 'Tablet Cards Per Row', 'ws-team-showcase-widget' ),
				'type'      => Controls_Manager::SELECT,
				'default'   => '2',
				'label_block' => true,
				'options'   => [
					'1' => '1',
					'2' => '2',
					'3' => '3',
					'4' => '4',
				],
			]
		);

		$this->add_control(
			'grid_columns_mobile',
			[
				'label'       => esc_html__( 'Mobile Cards Per Row', 'ws-team-showcase-widget' ),
				'type'      => Controls_Manager::SELECT,
				'default'   => '1',
				'label_block' => true,
				'options'   => [
					'1' => '1',
					'2' => '2',
				],
			]
		);

		$this->add_control(
			'show_view_switcher',
			[
				'label'        => esc_html__( 'Grid / List View Switcher', 'ws-team-showcase-widget' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'Show', 'ws-team-showcase-widget' ),
				'label_off'    => esc_html__( 'Hide', 'ws-team-showcase-widget' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			]
		);

		$this->add_control(
			'default_view',
			[
				'label'     => esc_html__( 'Default View', 'ws-team-showcase-widget' ),
				'type'      => Controls_Manager::SELECT,
				'default'   => 'grid',
				'options'   => [
					'grid' => esc_html__( 'Grid', 'ws-team-showcase-widget' ),
					'list' => esc_html__( 'List', 'ws-team-showcase-widget' ),
				],
				'condition' => [
					'show_view_switcher' => 'yes',
				],
			]
		);

		$this->end_controls_section();
	}

	private function register_layout_controls(): void {
		$this->start_controls_section(
			'section_layout',
			[ 'label' => esc_html__( 'Layout', 'ws-team-showcase-widget' ) ]
		);

		$this->add_control(
			'card_alignment',
			[
				'label'   => esc_html__( 'Card Alignment', 'ws-team-showcase-widget' ),
				'type'    => Controls_Manager::CHOOSE,
				'default' => 'left',
				'options' => [
					'left'   => [ 'title' => esc_html__( 'Left', 'ws-team-showcase-widget' ), 'icon' => 'eicon-text-align-left' ],
					'center' => [ 'title' => esc_html__( 'Center', 'ws-team-showcase-widget' ), 'icon' => 'eicon-text-align-center' ],
					'right'  => [ 'title' => esc_html__( 'Right', 'ws-team-showcase-widget' ), 'icon' => 'eicon-text-align-right' ],
				],
				'selectors' => [
					'{{WRAPPER}} .ws-team-card' => 'text-align: {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'card_height',
			[
				'label'      => esc_html__( 'Card Height', 'ws-team-showcase-widget' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'vh' ],
				'range'      => [
					'px' => [ 'min' => 220, 'max' => 700 ],
					'vh' => [ 'min' => 20, 'max' => 90 ],
				],
				'selectors'  => [
					'{{WRAPPER}} .ws-team-card' => 'min-height: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'image_position',
			[
				'label'   => esc_html__( 'Image Position', 'ws-team-showcase-widget' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'top',
				'options' => [
					'top'  => esc_html__( 'Top', 'ws-team-showcase-widget' ),
					'left' => esc_html__( 'Left', 'ws-team-showcase-widget' ),
				],
			]
		);

		$this->add_control(
			'popup_enabled',
			[
				'label'        => esc_html__( 'Popup Toggle', 'ws-team-showcase-widget' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'On', 'ws-team-showcase-widget' ),
				'label_off'    => esc_html__( 'Off', 'ws-team-showcase-widget' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			]
		);

		$this->add_control(
			'show_department_filter',
			[
				'label'        => esc_html__( 'Department Filter', 'ws-team-showcase-widget' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'Show', 'ws-team-showcase-widget' ),
				'label_off'    => esc_html__( 'Hide', 'ws-team-showcase-widget' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			]
		);

		$this->add_control(
			'show_search_filter',
			[
				'label'        => esc_html__( 'Search Filter', 'ws-team-showcase-widget' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'Show', 'ws-team-showcase-widget' ),
				'label_off'    => esc_html__( 'Hide', 'ws-team-showcase-widget' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			]
		);

		$this->add_control(
			'search_icon',
			[
				'label'       => esc_html__( 'Search Icon', 'ws-team-showcase-widget' ),
				'type'        => Controls_Manager::ICONS,
				'default'     => [
					'value'   => 'fas fa-search',
					'library' => 'fa-solid',
				],
				'label_block' => true,
				'condition'   => [
					'show_search_filter' => 'yes',
				],
			]
		);

		$this->add_control(
			'lazy_loading',
			[
				'label'        => esc_html__( 'Lazy Loading', 'ws-team-showcase-widget' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'On', 'ws-team-showcase-widget' ),
				'label_off'    => esc_html__( 'Off', 'ws-team-showcase-widget' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			]
		);

		$this->add_control(
			'skeleton_loader',
			[
				'label'        => esc_html__( 'Skeleton Loader', 'ws-team-showcase-widget' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'On', 'ws-team-showcase-widget' ),
				'label_off'    => esc_html__( 'Off', 'ws-team-showcase-widget' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			]
		);

		$this->add_control(
			'gsap_animation',
			[
				'label'        => esc_html__( 'GSAP Animation', 'ws-team-showcase-widget' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'On', 'ws-team-showcase-widget' ),
				'label_off'    => esc_html__( 'Off', 'ws-team-showcase-widget' ),
				'return_value' => 'yes',
			]
		);

		$this->add_control(
			'dark_mode',
			[
				'label'        => esc_html__( 'Dark Mode Toggle', 'ws-team-showcase-widget' ),
				'type'         => Controls_Manager::SWITCHER,
				'return_value' => 'yes',
			]
		);

		$this->end_controls_section();
	}

	private function register_style_controls(): void {
		$this->start_controls_section(
			'section_card_style',
			[
				'label' => esc_html__( 'Card', 'ws-team-showcase-widget' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'card_background',
			[
				'label'     => esc_html__( 'Card Background', 'ws-team-showcase-widget' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ws-team-card' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'border_radius',
			[
				'label'      => esc_html__( 'Border Radius', 'ws-team-showcase-widget' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'default'    => [ 'size' => 0, 'unit' => 'px' ],
				'selectors'  => [
					'{{WRAPPER}} .ws-team-card' => 'border-radius: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'card_border',
				'selector' => '{{WRAPPER}} .ws-team-card',
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'card_shadow',
				'selector' => '{{WRAPPER}} .ws-team-card',
			]
		);

		$this->add_control(
			'hover_effect',
			[
				'label'   => esc_html__( 'Hover Effects', 'ws-team-showcase-widget' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'lift',
				'options' => [
					'none'  => esc_html__( 'None', 'ws-team-showcase-widget' ),
					'lift'  => esc_html__( 'Lift', 'ws-team-showcase-widget' ),
					'zoom'  => esc_html__( 'Image Zoom', 'ws-team-showcase-widget' ),
					'glow'  => esc_html__( 'Glow', 'ws-team-showcase-widget' ),
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_typography',
			[
				'label' => esc_html__( 'Typography', 'ws-team-showcase-widget' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'name_typography',
				'label'    => esc_html__( 'Name Typography', 'ws-team-showcase-widget' ),
				'selector' => '{{WRAPPER}} .ws-team-name',
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'designation_typography',
				'label'    => esc_html__( 'Designation Typography', 'ws-team-showcase-widget' ),
				'selector' => '{{WRAPPER}} .ws-team-designation',
			]
		);
		$this->add_control(
			'text_color',
			[
				'label'     => esc_html__( 'Text Color', 'ws-team-showcase-widget' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ws-team-card' => 'color: {{VALUE}};',
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_button_style',
			[
				'label' => esc_html__( 'Button Styling', 'ws-team-showcase-widget' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'button_color',
			[
				'label'     => esc_html__( 'Button Text Color', 'ws-team-showcase-widget' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#ffffff',
				'selectors' => [
					'{{WRAPPER}} .ws-team-button, {{WRAPPER}} .ws-team-details, {{WRAPPER}} .ws-team-load-more' => 'color: {{VALUE}};',
				],
			]
		);
		$this->add_control(
			'button_background',
			[
				'label'     => esc_html__( 'Button Background', 'ws-team-showcase-widget' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#1168f5',
				'selectors' => [
					'{{WRAPPER}} .ws-team-button, {{WRAPPER}} .ws-team-details, {{WRAPPER}} .ws-team-load-more' => 'background-color: {{VALUE}};',
				],
			]
		);
		$this->add_responsive_control(
			'button_radius',
			[
				'label'      => esc_html__( 'Button Border Radius', 'ws-team-showcase-widget' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'default'    => [ 'size' => 6, 'unit' => 'px' ],
				'selectors'  => [
					'{{WRAPPER}} .ws-team-button, {{WRAPPER}} .ws-team-details, {{WRAPPER}} .ws-team-load-more' => 'border-radius: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_search_style',
			[
				'label' => esc_html__( 'Search Bar', 'ws-team-showcase-widget' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_responsive_control(
			'search_width',
			[
				'label'      => esc_html__( 'Width', 'ws-team-showcase-widget' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range'      => [
					'px' => [ 'min' => 160, 'max' => 700 ],
					'%'  => [ 'min' => 20, 'max' => 100 ],
				],
				'default'    => [ 'size' => 320, 'unit' => 'px' ],
				'selectors'  => [
					'{{WRAPPER}} .ws-team-search-label' => 'width: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'search_background',
			[
				'label'     => esc_html__( 'Background', 'ws-team-showcase-widget' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#ffffff',
				'selectors' => [
					'{{WRAPPER}} .ws-team-search' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'search_text_color',
			[
				'label'     => esc_html__( 'Text Color', 'ws-team-showcase-widget' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#162033',
				'selectors' => [
					'{{WRAPPER}} .ws-team-search' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'search_placeholder_color',
			[
				'label'     => esc_html__( 'Placeholder Color', 'ws-team-showcase-widget' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#667085',
				'selectors' => [
					'{{WRAPPER}} .ws-team-search::placeholder' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'search_icon_color',
			[
				'label'     => esc_html__( 'Icon Color', 'ws-team-showcase-widget' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#667085',
				'selectors' => [
					'{{WRAPPER}} .ws-team-search-icon' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'search_icon_size',
			[
				'label'      => esc_html__( 'Icon Size', 'ws-team-showcase-widget' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],
				'range'      => [
					'px' => [ 'min' => 12, 'max' => 32 ],
				],
				'default'    => [ 'size' => 16, 'unit' => 'px' ],
				'selectors'  => [
					'{{WRAPPER}} .ws-team-search-icon' => 'font-size: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .ws-team-search-icon svg' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'search_padding',
			[
				'label'      => esc_html__( 'Padding', 'ws-team-showcase-widget' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em' ],
				'default'    => [
					'top'      => 12,
					'right'    => 16,
					'bottom'   => 12,
					'left'     => 44,
					'unit'     => 'px',
					'isLinked' => false,
				],
				'selectors'  => [
					'{{WRAPPER}} .ws-team-search' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'search_border_radius',
			[
				'label'      => esc_html__( 'Border Radius', 'ws-team-showcase-widget' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'default'    => [ 'size' => 8, 'unit' => 'px' ],
				'selectors'  => [
					'{{WRAPPER}} .ws-team-search' => 'border-radius: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'search_border',
				'selector' => '{{WRAPPER}} .ws-team-search',
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'search_shadow',
				'selector' => '{{WRAPPER}} .ws-team-search',
			]
		);

		$this->end_controls_section();
	}

	protected function render(): void {
		$settings       = $this->get_settings_for_display();
		$members        = WS_Team_Showcase_Ajax::sanitize_members( $this->get_members_from_settings( $settings ) );
		$departments    = WS_Team_Showcase_Ajax::get_departments( $members );
		$popup_enabled  = 'yes' === ( $settings['popup_enabled'] ?? 'yes' );
		$image_position = sanitize_key( $settings['image_position'] ?? 'top' );
		$hover_effect   = sanitize_key( $settings['hover_effect'] ?? 'lift' );
		$is_dark        = 'yes' === ( $settings['dark_mode'] ?? '' );
		$show_filters   = 'yes' === ( $settings['show_department_filter'] ?? 'yes' );
		$show_search    = 'yes' === ( $settings['show_search_filter'] ?? 'yes' );
		$show_views     = 'yes' === ( $settings['show_view_switcher'] ?? 'yes' );
		$default_view   = 'list' === ( $settings['default_view'] ?? 'grid' ) ? 'list' : 'grid';
		$lazy_loading   = 'yes' === ( $settings['lazy_loading'] ?? 'yes' );
		$skeleton       = 'yes' === ( $settings['skeleton_loader'] ?? 'yes' );
		$gsap           = 'yes' === ( $settings['gsap_animation'] ?? '' );
		$per_page       = WS_Team_Showcase_Ajax::PER_PAGE;
		$initial        = count( $members ) > $per_page ? array_slice( $members, 0, $per_page ) : $members;
		$instance_class = 'ws-team-showcase-' . $this->get_id();
		$desktop_cols   = $this->sanitize_column_count( $settings['grid_columns_desktop'] ?? 4, 4, 6 );
		$tablet_cols    = $this->sanitize_column_count( $settings['grid_columns_tablet'] ?? 2, 2, 4 );
		$mobile_cols    = $this->sanitize_column_count( $settings['grid_columns_mobile'] ?? 1, 1, 2 );
		$config         = [
			'members'       => $members,
			'popup'         => $popup_enabled ? 'yes' : 'no',
			'imagePosition' => $image_position,
			'perPage'       => $per_page,
			'lazyLoad'      => $lazy_loading ? 'yes' : 'no',
			'skeleton'      => $skeleton ? 'yes' : 'no',
			'gsap'          => $gsap ? 'yes' : 'no',
			'defaultView'   => $default_view,
		];

		if ( $gsap ) {
			wp_enqueue_script( 'ws-team-showcase-gsap' );
		}
		?>
		<style>
			.<?php echo esc_attr( $instance_class ); ?> .ws-team-grid,
			.<?php echo esc_attr( $instance_class ); ?> .ws-team-skeleton { --ws-team-columns: <?php echo esc_html( (string) $desktop_cols ); ?>; }
			.<?php echo esc_attr( $instance_class ); ?> .ws-team-name { display: block; text-align: left !important; width: 100%; }
			.<?php echo esc_attr( $instance_class ); ?> .ws-team-name-button { border-radius: 0 !important; display: inline-block !important; margin: 0 !important; min-height: 0 !important; padding: 0 !important; text-align: left !important; width: auto !important; }
			@media (max-width: 1024px) {
				.<?php echo esc_attr( $instance_class ); ?> .ws-team-grid,
				.<?php echo esc_attr( $instance_class ); ?> .ws-team-skeleton { --ws-team-columns: <?php echo esc_html( (string) $tablet_cols ); ?>; }
			}
			@media (max-width: 767px) {
				.<?php echo esc_attr( $instance_class ); ?> .ws-team-grid,
				.<?php echo esc_attr( $instance_class ); ?> .ws-team-skeleton { --ws-team-columns: <?php echo esc_html( (string) $mobile_cols ); ?>; }
			}
		</style>
		<div class="ws-team-showcase <?php echo esc_attr( $instance_class ); ?> ws-team-view-<?php echo esc_attr( $default_view ); ?> ws-team-hover-<?php echo esc_attr( $hover_effect ); ?> <?php echo $is_dark ? 'ws-team-dark' : ''; ?>" data-config="<?php echo esc_attr( wp_json_encode( $config ) ?: '{}' ); ?>">
			<?php if ( $show_filters || $show_search || $show_views ) : ?>
				<div class="ws-team-toolbar">
					<?php if ( $show_filters ) : ?>
						<div class="ws-team-filters" role="group" aria-label="<?php echo esc_attr__( 'Filter by department', 'ws-team-showcase-widget' ); ?>">
							<button class="ws-team-filter is-active" type="button" data-department="all"><?php echo esc_html__( 'All', 'ws-team-showcase-widget' ); ?></button>
							<?php foreach ( $departments as $slug => $department ) : ?>
								<button class="ws-team-filter" type="button" data-department="<?php echo esc_attr( $slug ); ?>"><?php echo esc_html( $department ); ?></button>
							<?php endforeach; ?>
						</div>
					<?php endif; ?>
					<?php if ( $show_search ) : ?>
						<label class="ws-team-search-label">
							<span class="screen-reader-text"><?php echo esc_html__( 'Search team members', 'ws-team-showcase-widget' ); ?></span>
							<span class="ws-team-search-icon" aria-hidden="true">
								<?php Icons_Manager::render_icon( $settings['search_icon'] ?? [ 'value' => 'fas fa-search', 'library' => 'fa-solid' ], [ 'aria-hidden' => 'true' ] ); ?>
							</span>
							<input class="ws-team-search" type="search" placeholder="<?php echo esc_attr__( 'Search team', 'ws-team-showcase-widget' ); ?>">
						</label>
					<?php endif; ?>
					<?php if ( $show_views ) : ?>
						<div class="ws-team-view-switcher" role="group" aria-label="<?php echo esc_attr__( 'Select team view', 'ws-team-showcase-widget' ); ?>">
							<button class="ws-team-view-button<?php echo 'grid' === $default_view ? ' is-active' : ''; ?>" type="button" data-view="grid" aria-pressed="<?php echo 'grid' === $default_view ? 'true' : 'false'; ?>">
								<svg class="ws-team-view-icon" viewBox="0 0 16 16" aria-hidden="true" focusable="false"><path d="M1 1h6v6H1zM9 1h6v6H9zM1 9h6v6H1zM9 9h6v6H9z"/></svg>
								<span><?php echo esc_html__( 'Grid', 'ws-team-showcase-widget' ); ?></span>
							</button>
							<button class="ws-team-view-button<?php echo 'list' === $default_view ? ' is-active' : ''; ?>" type="button" data-view="list" aria-pressed="<?php echo 'list' === $default_view ? 'true' : 'false'; ?>">
								<svg class="ws-team-view-icon" viewBox="0 0 16 16" aria-hidden="true" focusable="false"><path d="M1 2h3v3H1zM6 2h9v3H6zM1 7h3v3H1zM6 7h9v3H6zM1 12h3v3H1zM6 12h9v3H6z"/></svg>
								<span><?php echo esc_html__( 'List', 'ws-team-showcase-widget' ); ?></span>
							</button>
						</div>
					<?php endif; ?>
				</div>
			<?php endif; ?>

			<div class="ws-team-grid-wrap">
				<div class="ws-team-grid" aria-live="polite">
					<?php echo WS_Team_Showcase_Ajax::render_cards( $initial, $popup_enabled, $image_position, $lazy_loading ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
				</div>
				<div class="ws-team-loader" hidden>
					<span class="ws-team-loader-spinner"></span>
					<span class="ws-team-loader-text"><?php echo esc_html__( 'Loading team members...', 'ws-team-showcase-widget' ); ?></span>
				</div>
			</div>

			<div class="ws-team-empty"<?php echo empty( $members ) ? '' : ' hidden'; ?>><?php echo esc_html__( 'No team members found.', 'ws-team-showcase-widget' ); ?></div>

			<?php if ( $skeleton ) : ?>
				<div class="ws-team-skeleton" hidden>
					<span></span><span></span><span></span><span></span>
				</div>
			<?php endif; ?>

			<?php if ( count( $members ) > $per_page ) : ?>
				<div class="ws-team-load-more-wrap">
					<button class="ws-team-load-more" type="button"><?php echo esc_html__( 'Load More', 'ws-team-showcase-widget' ); ?></button>
				</div>
			<?php endif; ?>

			<?php if ( $popup_enabled ) : ?>
				<div class="ws-team-modal" aria-hidden="true">
					<div class="ws-team-modal-panel" role="dialog" aria-modal="true" aria-label="<?php echo esc_attr__( 'Team member details', 'ws-team-showcase-widget' ); ?>">
						<button class="ws-team-modal-close" type="button" aria-label="<?php echo esc_attr__( 'Close', 'ws-team-showcase-widget' ); ?>">&times;</button>
						<div class="ws-team-modal-body"></div>
					</div>
				</div>
			<?php endif; ?>
		</div>
		<?php
	}

	private function get_members_from_settings( array $settings ): array {
		if ( 'acf_repeater' === ( $settings['data_source'] ?? 'manual' ) ) {
			return $this->get_acf_members( absint( $settings['acf_showcase_id'] ?? 0 ) );
		}

		return $this->normalize_members( $settings['members'] ?? [] );
	}

	private function sanitize_column_count( $value, int $default, int $max ): int {
		$value = absint( $value );

		if ( $value < 1 ) {
			return $default;
		}

		return min( $value, $max );
	}

	private function normalize_members( array $members ): array {
		return array_map(
			static function ( array $member ): array {
				return [
					'name'         => $member['name'] ?? '',
					'designation'  => $member['designation'] ?? '',
					'department'   => $member['department'] ?? '',
					'bio'          => $member['bio'] ?? '',
					'image'        => $member['image']['url'] ?? '',
					'experience'   => $member['experience'] ?? '',
					'button_type'  => $member['button_type'] ?? 'default',
					'button_text'  => $member['button_text'] ?? '',
					'button_url'   => $member['button_url']['url'] ?? '',
					'button_target' => ! empty( $member['button_url']['is_external'] ) ? '_blank' : '',
					'button_nofollow' => ! empty( $member['button_url']['nofollow'] ) ? 'nofollow' : '',
					'button_icon'  => self::normalize_icon( $member['button_icon'] ?? [] ),
					'button_icon_position' => $member['button_icon_position'] ?? 'before',
					'button_icon_spacing' => $member['button_icon_spacing']['size'] ?? 8,
					'button_id'    => $member['button_id'] ?? '',
					'social_links' => self::parse_social_links( $member['social_links'] ?? '' ),
				];
			},
			$members
		);
	}

	private function get_acf_members( int $post_id ): array {
		if ( ! $post_id || ! function_exists( 'get_field' ) ) {
			return [];
		}

		$post = get_post( $post_id );
		if ( ! $post || WS_Team_Showcase_Post_Types::POST_TYPE !== $post->post_type || 'publish' !== $post->post_status ) {
			return [];
		}

		$members = get_field( WS_Team_Showcase_Post_Types::ACF_REPEATER, $post_id );
		if ( ! is_array( $members ) ) {
			return [];
		}

		return array_map(
			static function ( array $member ): array {
				return [
					'name'         => $member['name'] ?? '',
					'designation'  => $member['designation'] ?? '',
					'department'   => $member['department'] ?? '',
					'bio'          => $member['bio'] ?? '',
					'image'        => self::normalize_acf_image_url( $member['image'] ?? '' ),
					'experience'   => $member['experience'] ?? '',
					'button_type'  => 'default',
					'button_text'  => $member['button_text'] ?? '',
					'button_url'   => $member['button_url'] ?? '',
					'button_target' => '',
					'button_nofollow' => '',
					'button_icon'  => [],
					'button_icon_position' => 'before',
					'button_icon_spacing' => 8,
					'button_id'    => '',
					'social_links' => self::normalize_acf_social_links( $member['social_links'] ?? [] ),
				];
			},
			$members
		);
	}

	private static function normalize_acf_image_url( $image ): string {
		if ( is_array( $image ) ) {
			return (string) ( $image['url'] ?? '' );
		}

		if ( is_numeric( $image ) ) {
			return (string) wp_get_attachment_image_url( absint( $image ), 'large' );
		}

		return is_string( $image ) ? $image : '';
	}

	private static function normalize_acf_social_links( $links ): array {
		if ( ! is_array( $links ) ) {
			return [];
		}

		$clean = [];

		foreach ( $links as $link ) {
			if ( ! is_array( $link ) ) {
				continue;
			}

			$clean[] = [
				'label' => $link['label'] ?? '',
				'url'   => $link['url'] ?? '',
			];
		}

		return $clean;
	}

	private static function normalize_icon( $icon ): array {
		if ( ! is_array( $icon ) ) {
			return [];
		}

		return [
			'value'   => is_string( $icon['value'] ?? '' ) ? $icon['value'] : '',
			'library' => is_string( $icon['library'] ?? '' ) ? $icon['library'] : '',
		];
	}

	private static function parse_social_links( string $value ): array {
		$links = [];
		$rows  = preg_split( '/\r\n|\r|\n/', $value );

		foreach ( $rows ?: [] as $row ) {
			$row = trim( $row );
			if ( '' === $row ) {
				continue;
			}

			$parts   = array_map( 'trim', explode( '|', $row, 2 ) );
			$links[] = [
				'label' => $parts[0] ?? '',
				'url'   => $parts[1] ?? '',
			];
		}

		return $links;
	}

	private function get_acf_showcase_options(): array {
		$options = [];
		$posts   = get_posts(
			[
				'post_type'      => WS_Team_Showcase_Post_Types::POST_TYPE,
				'post_status'    => 'publish',
				'posts_per_page' => 100,
				'orderby'        => 'title',
				'order'          => 'ASC',
				'no_found_rows'  => true,
			]
		);

		foreach ( $posts as $post ) {
			$options[ $post->ID ] = $post->post_title;
		}

		if ( empty( $options ) ) {
			$options[0] = esc_html__( 'No Team Showcases found', 'ws-team-showcase-widget' );
		}

		return $options;
	}

	private function get_default_members(): array {
		$departments = [ 'Design', 'Development', 'Marketing', 'Strategy', 'Design', 'Development', 'Marketing', 'Strategy', 'Operations' ];
		$members     = [];

		foreach ( $departments as $index => $department ) {
			$members[] = [
				'name'        => sprintf( 'Team Member %d', $index + 1 ),
				'designation' => 'Specialist',
				'department'  => $department,
				'bio'         => 'Experienced team contributor focused on client outcomes and practical delivery.',
				'experience'  => ( 3 + $index ) . '+ years experience',
				'button_text' => 'View Profile',
			];
		}

		return $members;
	}
}
