<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class WS_Team_Showcase_Post_Types {
	public const POST_TYPE = 'ws_team_showcase';
	public const ACF_REPEATER = 'ws_team_members';

	public static function register(): void {
		add_action( 'init', [ __CLASS__, 'register_post_type' ] );
		add_action( 'acf/init', [ __CLASS__, 'register_acf_fields' ] );
		add_action( 'admin_notices', [ __CLASS__, 'acf_missing_notice' ] );
	}

	public static function activate(): void {
		self::register_post_type();
		flush_rewrite_rules();
	}

	public static function deactivate(): void {
		flush_rewrite_rules();
	}

	public static function register_post_type(): void {
		$labels = [
			'name'               => esc_html__( 'Team Showcases', 'ws-team-showcase-widget' ),
			'singular_name'      => esc_html__( 'Team Showcase', 'ws-team-showcase-widget' ),
			'menu_name'          => esc_html__( 'Team Showcases', 'ws-team-showcase-widget' ),
			'add_new_item'       => esc_html__( 'Add New Team Showcase', 'ws-team-showcase-widget' ),
			'edit_item'          => esc_html__( 'Edit Team Showcase', 'ws-team-showcase-widget' ),
			'new_item'           => esc_html__( 'New Team Showcase', 'ws-team-showcase-widget' ),
			'view_item'          => esc_html__( 'View Team Showcase', 'ws-team-showcase-widget' ),
			'search_items'       => esc_html__( 'Search Team Showcases', 'ws-team-showcase-widget' ),
			'not_found'          => esc_html__( 'No team showcases found.', 'ws-team-showcase-widget' ),
			'not_found_in_trash' => esc_html__( 'No team showcases found in Trash.', 'ws-team-showcase-widget' ),
		];

		register_post_type(
			self::POST_TYPE,
			[
				'labels'        => $labels,
				'public'        => false,
				'show_ui'       => true,
				'show_in_menu'  => true,
				'menu_icon'     => 'dashicons-groups',
				'supports'      => [ 'title' ],
				'capability_type' => 'post',
				'has_archive'   => false,
				'rewrite'       => false,
				'show_in_rest'  => true,
			]
		);
	}

	public static function register_acf_fields(): void {
		if ( ! function_exists( 'acf_add_local_field_group' ) ) {
			return;
		}

		acf_add_local_field_group(
			[
				'key'                   => 'group_ws_team_showcase_members',
				'title'                 => esc_html__( 'WS Team Showcase Members', 'ws-team-showcase-widget' ),
				'fields'                => [
					[
						'key'          => 'field_ws_team_members',
						'label'        => esc_html__( 'Team Members', 'ws-team-showcase-widget' ),
						'name'         => self::ACF_REPEATER,
						'type'         => 'repeater',
						'layout'       => 'block',
						'button_label' => esc_html__( 'Add Team Member', 'ws-team-showcase-widget' ),
						'sub_fields'   => self::get_acf_member_sub_fields(),
					],
				],
				'location'              => [
					[
						[
							'param'    => 'post_type',
							'operator' => '==',
							'value'    => self::POST_TYPE,
						],
					],
				],
				'position'              => 'normal',
				'style'                 => 'default',
				'label_placement'       => 'top',
				'instruction_placement' => 'label',
				'active'                => true,
				'show_in_rest'          => 0,
			]
		);
	}

	private static function get_acf_member_sub_fields(): array {
		return [
			[
				'key'           => 'field_ws_team_name',
				'label'         => esc_html__( 'Name', 'ws-team-showcase-widget' ),
				'name'          => 'name',
				'type'          => 'text',
				'required'      => 1,
				'wrapper'       => [ 'width' => '50' ],
			],
			[
				'key'     => 'field_ws_team_designation',
				'label'   => esc_html__( 'Designation', 'ws-team-showcase-widget' ),
				'name'    => 'designation',
				'type'    => 'text',
				'wrapper' => [ 'width' => '50' ],
			],
			[
				'key'     => 'field_ws_team_department',
				'label'   => esc_html__( 'Department', 'ws-team-showcase-widget' ),
				'name'    => 'department',
				'type'    => 'text',
				'wrapper' => [ 'width' => '50' ],
			],
			[
				'key'     => 'field_ws_team_experience',
				'label'   => esc_html__( 'Experience', 'ws-team-showcase-widget' ),
				'name'    => 'experience',
				'type'    => 'text',
				'wrapper' => [ 'width' => '50' ],
			],
			[
				'key'   => 'field_ws_team_bio',
				'label' => esc_html__( 'Short Bio', 'ws-team-showcase-widget' ),
				'name'  => 'bio',
				'type'  => 'textarea',
				'rows'  => 4,
			],
			[
				'key'           => 'field_ws_team_image',
				'label'         => esc_html__( 'Profile Image', 'ws-team-showcase-widget' ),
				'name'          => 'image',
				'type'          => 'image',
				'return_format' => 'array',
				'preview_size'  => 'medium',
				'library'       => 'all',
			],
			[
				'key'          => 'field_ws_team_social_links',
				'label'        => esc_html__( 'Social Links', 'ws-team-showcase-widget' ),
				'name'         => 'social_links',
				'type'         => 'repeater',
				'layout'       => 'table',
				'button_label' => esc_html__( 'Add Social Link', 'ws-team-showcase-widget' ),
				'sub_fields'   => [
					[
						'key'     => 'field_ws_team_social_label',
						'label'   => esc_html__( 'Label', 'ws-team-showcase-widget' ),
						'name'    => 'label',
						'type'    => 'text',
						'wrapper' => [ 'width' => '40' ],
					],
					[
						'key'     => 'field_ws_team_social_url',
						'label'   => esc_html__( 'URL', 'ws-team-showcase-widget' ),
						'name'    => 'url',
						'type'    => 'url',
						'wrapper' => [ 'width' => '60' ],
					],
				],
			],
			[
				'key'     => 'field_ws_team_button_text',
				'label'   => esc_html__( 'Button Text', 'ws-team-showcase-widget' ),
				'name'    => 'button_text',
				'type'    => 'text',
				'wrapper' => [ 'width' => '50' ],
			],
			[
				'key'     => 'field_ws_team_button_url',
				'label'   => esc_html__( 'Button URL', 'ws-team-showcase-widget' ),
				'name'    => 'button_url',
				'type'    => 'url',
				'wrapper' => [ 'width' => '50' ],
			],
		];
	}

	public static function acf_missing_notice(): void {
		if ( ! is_admin() || ! current_user_can( 'activate_plugins' ) || function_exists( 'acf_add_local_field_group' ) ) {
			return;
		}

		echo '<div class="notice notice-info"><p>';
		echo esc_html__( 'WS Team Showcase Widget: install and activate Advanced Custom Fields to use the ACF Repeater source. Manual Elementor entries still work.', 'ws-team-showcase-widget' );
		echo '</p></div>';
	}
}
