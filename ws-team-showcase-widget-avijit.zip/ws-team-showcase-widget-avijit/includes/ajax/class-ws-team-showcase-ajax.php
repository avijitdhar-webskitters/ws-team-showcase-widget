<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class WS_Team_Showcase_Ajax {
	public const NONCE_ACTION = 'ws_team_showcase_nonce';
	public const PER_PAGE = 8;

	public static function register(): void {
		add_action( 'wp_ajax_ws_team_showcase_filter', [ __CLASS__, 'filter_members' ] );
		add_action( 'wp_ajax_nopriv_ws_team_showcase_filter', [ __CLASS__, 'filter_members' ] );
	}

	public static function filter_members(): void {
		check_ajax_referer( self::NONCE_ACTION, 'nonce' );

		$members    = isset( $_POST['members'] ) && is_array( $_POST['members'] ) ? wp_unslash( $_POST['members'] ) : [];
		$department = isset( $_POST['department'] ) ? sanitize_text_field( wp_unslash( $_POST['department'] ) ) : 'all';
		$search     = isset( $_POST['search'] ) ? sanitize_text_field( wp_unslash( $_POST['search'] ) ) : '';
		$page       = isset( $_POST['page'] ) ? max( 1, absint( $_POST['page'] ) ) : 1;
		$popup      = isset( $_POST['popup'] ) && 'yes' === sanitize_key( wp_unslash( $_POST['popup'] ) );
		$image_pos  = isset( $_POST['imagePosition'] ) ? sanitize_key( wp_unslash( $_POST['imagePosition'] ) ) : 'top';
		$lazy_load  = ! isset( $_POST['lazyLoad'] ) || 'yes' === sanitize_key( wp_unslash( $_POST['lazyLoad'] ) );

		$members  = self::sanitize_members( $members );
		$filtered = self::filter_member_list( $members, $department, $search );
		$total    = count( $filtered );
		$visible  = array_slice( $filtered, self::PER_PAGE * ( $page - 1 ), self::PER_PAGE );
		$shown    = min( $total, self::PER_PAGE * $page );

		wp_send_json_success(
			[
				'html'       => self::render_cards( $visible, $popup, $image_pos, $lazy_load ),
				'total'      => $total,
				'shown'      => $shown,
				'hasMore'    => $total > $shown,
				'noResults'  => 0 === $total,
				'nextPage'   => $page + 1,
			]
		);
	}

	public static function sanitize_members( array $members ): array {
		$clean = [];

		foreach ( $members as $member ) {
			if ( ! is_array( $member ) ) {
				continue;
			}

			$social_links = [];
			if ( ! empty( $member['social_links'] ) && is_array( $member['social_links'] ) ) {
				foreach ( $member['social_links'] as $link ) {
					if ( ! is_array( $link ) ) {
						continue;
					}

					$social_links[] = [
						'label' => sanitize_text_field( $link['label'] ?? '' ),
						'url'   => esc_url_raw( $link['url'] ?? '' ),
					];
				}
			}

			$clean[] = [
				'name'         => sanitize_text_field( $member['name'] ?? '' ),
				'designation'  => sanitize_text_field( $member['designation'] ?? '' ),
				'department'   => sanitize_text_field( $member['department'] ?? '' ),
				'bio'          => wp_kses_post( $member['bio'] ?? '' ),
				'image'        => esc_url_raw( $member['image'] ?? '' ),
				'experience'   => sanitize_text_field( $member['experience'] ?? '' ),
				'button_type'  => self::sanitize_button_type( $member['button_type'] ?? 'default' ),
				'button_text'  => sanitize_text_field( $member['button_text'] ?? '' ),
				'button_url'   => esc_url_raw( $member['button_url'] ?? '' ),
				'button_target' => '_blank' === ( $member['button_target'] ?? '' ) ? '_blank' : '',
				'button_nofollow' => 'nofollow' === ( $member['button_nofollow'] ?? '' ) ? 'nofollow' : '',
				'button_icon'  => self::sanitize_icon( $member['button_icon'] ?? [] ),
				'button_icon_position' => 'after' === ( $member['button_icon_position'] ?? '' ) ? 'after' : 'before',
				'button_icon_spacing' => isset( $member['button_icon_spacing'] ) ? absint( $member['button_icon_spacing'] ) : 8,
				'button_id'    => sanitize_html_class( $member['button_id'] ?? '' ),
				'social_links' => $social_links,
			];
		}

		return $clean;
	}

	public static function filter_member_list( array $members, string $department = 'all', string $search = '' ): array {
		return array_values(
			array_filter(
				$members,
				static function ( array $member ) use ( $department, $search ): bool {
					$department_match = 'all' === $department || sanitize_title( $member['department'] ) === sanitize_title( $department );
					$haystack         = strtolower( $member['name'] . ' ' . $member['designation'] . ' ' . $member['department'] . ' ' . wp_strip_all_tags( $member['bio'] ) );
					$search_match     = '' === $search || false !== strpos( $haystack, strtolower( $search ) );

					return $department_match && $search_match;
				}
			)
		);
	}

	public static function get_departments( array $members ): array {
		$departments = [];

		foreach ( $members as $member ) {
			if ( empty( $member['department'] ) ) {
				continue;
			}

			$departments[ sanitize_title( $member['department'] ) ] = $member['department'];
		}

		return $departments;
	}

	public static function render_cards( array $members, bool $popup_enabled = true, string $image_position = 'top', bool $lazy_load = true ): string {
		ob_start();

		foreach ( $members as $member ) {
			$modal_payload = wp_json_encode( $member );
			?>
			<article class="ws-team-card ws-team-image-<?php echo esc_attr( $image_position ); ?>" data-member="<?php echo esc_attr( $modal_payload ?: '{}' ); ?>">
				<?php if ( ! empty( $member['image'] ) ) : ?>
					<<?php echo $popup_enabled ? 'button' : 'div'; ?> class="ws-team-image-wrap<?php echo $popup_enabled ? ' ws-team-popup-trigger' : ''; ?>"<?php echo $popup_enabled ? ' type="button" aria-label="' . esc_attr__( 'View team member details', 'ws-team-showcase-widget' ) . '"' : ''; ?>>
						<img class="ws-team-image" src="<?php echo esc_url( $member['image'] ); ?>" alt="<?php echo esc_attr( $member['name'] ); ?>"<?php echo $lazy_load ? ' loading="lazy"' : ''; ?>>
					</<?php echo $popup_enabled ? 'button' : 'div'; ?>>
				<?php endif; ?>

				<div class="ws-team-content">
					<?php if ( ! empty( $member['department'] ) ) : ?>
						<span class="ws-team-department"><?php echo esc_html( $member['department'] ); ?></span>
					<?php endif; ?>
					<?php if ( ! empty( $member['name'] ) ) : ?>
						<h3 class="ws-team-name">
							<?php if ( $popup_enabled ) : ?>
								<button class="ws-team-name-button ws-team-popup-trigger" type="button"><?php echo esc_html( $member['name'] ); ?></button>
							<?php else : ?>
								<?php echo esc_html( $member['name'] ); ?>
							<?php endif; ?>
						</h3>
					<?php endif; ?>
					<?php if ( ! empty( $member['designation'] ) ) : ?>
						<p class="ws-team-designation"><?php echo esc_html( $member['designation'] ); ?></p>
					<?php endif; ?>
					<?php if ( ! empty( $member['bio'] ) ) : ?>
						<div class="ws-team-bio"><?php echo wp_kses_post( wp_trim_words( $member['bio'], 20 ) ); ?></div>
					<?php endif; ?>
					<?php if ( ! empty( $member['experience'] ) ) : ?>
						<p class="ws-team-experience"><?php echo esc_html( $member['experience'] ); ?></p>
					<?php endif; ?>
					<?php echo self::render_social_links( $member['social_links'] ?? [] ); ?>
					<div class="ws-team-actions">
						<?php if ( ! empty( $member['button_text'] ) && ! empty( $member['button_url'] ) ) : ?>
							<?php echo self::render_button( $member ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
						<?php endif; ?>
					</div>
				</div>
			</article>
			<?php
		}

		return (string) ob_get_clean();
	}

	private static function render_social_links( array $links ): string {
		if ( empty( $links ) ) {
			return '';
		}

		ob_start();
		?>
		<div class="ws-team-socials">
			<?php foreach ( $links as $link ) : ?>
				<?php if ( ! empty( $link['url'] ) ) : ?>
					<a href="<?php echo esc_url( $link['url'] ); ?>" target="_blank" rel="noopener noreferrer">
						<?php echo esc_html( $link['label'] ?: __( 'Social', 'ws-team-showcase-widget' ) ); ?>
					</a>
				<?php endif; ?>
			<?php endforeach; ?>
		</div>
		<?php

		return (string) ob_get_clean();
	}

	private static function render_button( array $member ): string {
		$icon_position = 'after' === ( $member['button_icon_position'] ?? '' ) ? 'after' : 'before';
		$spacing       = isset( $member['button_icon_spacing'] ) ? absint( $member['button_icon_spacing'] ) : 8;
		$rel           = 'nofollow' === ( $member['button_nofollow'] ?? '' ) ? 'nofollow' : '';
		$target        = '_blank' === ( $member['button_target'] ?? '' ) ? '_blank' : '';
		$id            = ! empty( $member['button_id'] ) ? sanitize_html_class( $member['button_id'] ) : '';
		$type          = self::sanitize_button_type( $member['button_type'] ?? 'default' );

		ob_start();
		?>
		<a
			<?php echo $id ? 'id="' . esc_attr( $id ) . '"' : ''; ?>
			class="ws-team-button ws-team-button-type-<?php echo esc_attr( $type ); ?> ws-team-button-icon-<?php echo esc_attr( $icon_position ); ?>"
			href="<?php echo esc_url( $member['button_url'] ); ?>"
			<?php echo $target ? 'target="' . esc_attr( $target ) . '"' : ''; ?>
			<?php echo $rel ? 'rel="' . esc_attr( trim( $rel . ( $target ? ' noopener noreferrer' : '' ) ) ) . '"' : ( $target ? 'rel="noopener noreferrer"' : '' ); ?>
			style="--ws-team-button-icon-spacing: <?php echo esc_attr( (string) $spacing ); ?>px;"
		>
			<?php if ( 'before' === $icon_position ) : ?>
				<?php echo self::render_button_icon( $member['button_icon'] ?? [] ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
			<?php endif; ?>
			<span class="ws-team-button-text"><?php echo esc_html( $member['button_text'] ); ?></span>
			<?php if ( 'after' === $icon_position ) : ?>
				<?php echo self::render_button_icon( $member['button_icon'] ?? [] ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
			<?php endif; ?>
		</a>
		<?php

		return (string) ob_get_clean();
	}

	private static function render_button_icon( array $icon ): string {
		if ( empty( $icon['value'] ) || ! class_exists( '\Elementor\Icons_Manager' ) ) {
			return '';
		}

		ob_start();
		?>
		<span class="ws-team-button-icon" aria-hidden="true">
			<?php \Elementor\Icons_Manager::render_icon( $icon, [ 'aria-hidden' => 'true' ] ); ?>
		</span>
		<?php

		return (string) ob_get_clean();
	}

	private static function sanitize_button_type( string $type ): string {
		$type    = sanitize_key( $type );
		$allowed = [ 'default', 'info', 'success', 'warning', 'danger' ];

		return in_array( $type, $allowed, true ) ? $type : 'default';
	}

	private static function sanitize_icon( $icon ): array {
		if ( ! is_array( $icon ) ) {
			return [];
		}

		return [
			'value'   => sanitize_text_field( $icon['value'] ?? '' ),
			'library' => sanitize_text_field( $icon['library'] ?? '' ),
		];
	}
}
