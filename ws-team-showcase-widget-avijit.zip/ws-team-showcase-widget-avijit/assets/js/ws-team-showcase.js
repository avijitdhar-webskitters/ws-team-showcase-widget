(function ($) {
	'use strict';

	function initShowcase($root) {
		if (!$root.length || $root.data('wsTeamInitialized')) {
			return;
		}

		$root.data('wsTeamInitialized', true);

		var config = $root.data('config') || {};
		var state = {
			department: 'all',
			search: '',
			page: 1,
			view: config.defaultView === 'list' ? 'list' : 'grid',
			loading: false,
			requestId: 0,
			currentRequest: null,
			cache: {}
		};

		function setView(view) {
			state.view = view === 'list' ? 'list' : 'grid';
			$root.removeClass('ws-team-view-grid ws-team-view-list').addClass('ws-team-view-' + state.view);
			$root.find('.ws-team-view-button').each(function () {
				var $button = $(this);
				var isActive = $button.data('view') === state.view;

				$button.toggleClass('is-active', isActive).attr('aria-pressed', isActive ? 'true' : 'false');
			});
		}

		function setLoading(isLoading, append) {
			var $loadMore = $root.find('.ws-team-load-more');
			var labels = window.wsTeamShowcase && window.wsTeamShowcase.i18n ? window.wsTeamShowcase.i18n : {};

			state.loading = isLoading;

			$root.find('.ws-team-skeleton').prop('hidden', true);
			if (config.skeleton !== 'no' && isLoading && !append && !$root.find('.ws-team-card').length) {
				$root.find('.ws-team-skeleton').prop('hidden', false);
			}

			$root.find('.ws-team-loader').prop('hidden', !isLoading);
			$root.find('.ws-team-grid').toggleClass('is-loading', isLoading && !append);
			$root.toggleClass('is-loading-more', isLoading && !!append);

			if ($loadMore.length) {
				$loadMore.prop('disabled', isLoading);
				$loadMore.text(isLoading && append ? (labels.loading || 'Loading...') : (labels.loadMore || 'Load More'));
			}
		}

		function getCacheKey() {
			return [
				state.department,
				state.search,
				state.page,
				config.popup || 'yes',
				config.imagePosition || 'top',
				config.lazyLoad || 'yes'
			].join('|');
		}

		function applyResponse(data, append) {
			var $grid = $root.find('.ws-team-grid');

			if (append) {
				var $items = $(data.html);
				$grid.append($items);
				animateCards($items);
			} else {
				$grid.html(data.html);
				animateCards($grid.find('.ws-team-card'));
			}

			$root.find('.ws-team-empty').prop('hidden', !data.noResults);
			$root.find('.ws-team-load-more-wrap').prop('hidden', !data.hasMore);
		}

		function animateCards($cards) {
			if (config.gsap !== 'yes' || !window.gsap || !$cards.length) {
				return;
			}

			window.gsap.fromTo(
				$cards.toArray(),
				{ autoAlpha: 0, y: 22 },
				{ autoAlpha: 1, y: 0, duration: 0.45, stagger: 0.06, ease: 'power2.out' }
			);
		}

		function requestMembers(append) {
			var requestId;
			var cacheKey = getCacheKey();

			if (state.cache[cacheKey]) {
				applyResponse(state.cache[cacheKey], append);
				return;
			}

			if (state.loading && append) {
				return;
			}

			requestId = ++state.requestId;

			if (state.currentRequest && state.currentRequest.readyState !== 4) {
				state.currentRequest.abort();
			}

			setLoading(true, append);

			state.currentRequest = $.ajax({
				url: window.wsTeamShowcase.ajaxUrl,
				type: 'POST',
				dataType: 'json',
				data: {
					action: 'ws_team_showcase_filter',
					nonce: window.wsTeamShowcase.nonce,
					members: config.members || [],
					department: state.department,
					search: state.search,
					page: state.page,
					popup: config.popup || 'yes',
					imagePosition: config.imagePosition || 'top',
					lazyLoad: config.lazyLoad || 'yes'
				}
			}).done(function (response) {
				if (requestId !== state.requestId || !response || !response.success) {
					return;
				}

				var data = response.data;
				state.cache[cacheKey] = data;
				applyResponse(data, append);
			}).always(function () {
				if (requestId !== state.requestId) {
					return;
				}

				setLoading(false, append);
			});
		}

		function resetAndFetch() {
			state.page = 1;
			requestMembers(false);
		}

		$root.on('click', '.ws-team-filter', function () {
			var $button = $(this);
			state.department = $button.data('department') || 'all';
			$root.find('.ws-team-filter').removeClass('is-active');
			$button.addClass('is-active');
			resetAndFetch();
		});

		var searchTimer;
		$root.on('input', '.ws-team-search', function () {
			var value = $(this).val();
			window.clearTimeout(searchTimer);
			searchTimer = window.setTimeout(function () {
				state.search = value;
				resetAndFetch();
			}, 180);
		});

		$root.on('click', '.ws-team-load-more', function () {
			if (state.loading) {
				return;
			}

			state.page += 1;
			requestMembers(true);
		});

		$root.on('click', '.ws-team-view-button', function () {
			setView($(this).data('view'));
		});

		setView(state.view);
		animateCards($root.find('.ws-team-card'));

		$root.on('click', '.ws-team-popup-trigger', function () {
			var member = $(this).closest('.ws-team-card').data('member') || {};
			openModal($root, member);
		});

		$root.on('click', '.ws-team-modal-close, .ws-team-modal', function (event) {
			if ($(event.target).is('.ws-team-modal-close, .ws-team-modal')) {
				closeModal($root);
			}
		});

		$(document).on('keydown.wsTeamShowcase', function (event) {
			if (event.key === 'Escape') {
				closeModal($root);
			}
		});
	}

	function escapeHtml(value) {
		return $('<div>').text(value || '').html();
	}

	function openModal($root, member) {
		var socials = '';

		if (Array.isArray(member.social_links)) {
			member.social_links.forEach(function (link) {
				if (link.url) {
					socials += '<a href="' + escapeHtml(link.url) + '" target="_blank" rel="noopener noreferrer">' + escapeHtml(link.label || 'Social') + '</a>';
				}
			});
		}

		var html = '<div class="ws-team-modal-profile">';
		if (member.image) {
			html += '<img src="' + escapeHtml(member.image) + '" alt="' + escapeHtml(member.name) + '" loading="lazy">';
		}
		html += '<div>';
		html += '<span class="ws-team-department">' + escapeHtml(member.department) + '</span>';
		html += '<h3>' + escapeHtml(member.name) + '</h3>';
		html += '<p class="ws-team-designation">' + escapeHtml(member.designation) + '</p>';
		html += '<div class="ws-team-modal-bio">' + (member.bio || '') + '</div>';
		html += '<p class="ws-team-experience">' + escapeHtml(member.experience) + '</p>';
		if (socials) {
			html += '<div class="ws-team-socials">' + socials + '</div>';
		}
		if (member.button_text && member.button_url) {
			var buttonType = member.button_type || 'default';
			var iconPosition = member.button_icon_position === 'after' ? 'after' : 'before';
			var iconSpacing = parseInt(member.button_icon_spacing, 10);
			var iconHtml = '';
			var target = member.button_target === '_blank' ? ' target="_blank"' : '';
			var rel = member.button_target === '_blank' ? ' rel="noopener noreferrer"' : '';
			var id = member.button_id ? ' id="' + escapeHtml(member.button_id) + '"' : '';

			if (member.button_icon && member.button_icon.value) {
				iconHtml = '<span class="ws-team-button-icon" aria-hidden="true"><i class="' + escapeHtml(member.button_icon.value) + '"></i></span>';
			}

			if (Number.isNaN(iconSpacing)) {
				iconSpacing = 8;
			}

			html += '<a' + id + ' class="ws-team-button ws-team-button-type-' + escapeHtml(buttonType) + ' ws-team-button-icon-' + escapeHtml(iconPosition) + '" href="' + escapeHtml(member.button_url) + '"' + target + rel + ' style="--ws-team-button-icon-spacing: ' + iconSpacing + 'px;">';
			if (iconPosition === 'before') {
				html += iconHtml;
			}
			html += '<span class="ws-team-button-text">' + escapeHtml(member.button_text) + '</span>';
			if (iconPosition === 'after') {
				html += iconHtml;
			}
			html += '</a>';
		}
		html += '</div></div>';

		$root.find('.ws-team-modal-body').html(html);
		$root.find('.ws-team-modal').attr('aria-hidden', 'false').addClass('is-open');
	}

	function closeModal($root) {
		$root.find('.ws-team-modal').attr('aria-hidden', 'true').removeClass('is-open');
	}

	$(window).on('elementor/frontend/init', function () {
		elementorFrontend.hooks.addAction('frontend/element_ready/ws_team_showcase.default', function ($scope) {
			initShowcase($scope.find('.ws-team-showcase'));
		});
	});

	$(function () {
		$('.ws-team-showcase').each(function () {
			initShowcase($(this));
		});
	});
})(jQuery);
