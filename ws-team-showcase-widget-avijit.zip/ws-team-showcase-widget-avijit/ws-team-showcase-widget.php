<?php
/**
 * Plugin Name: WS Team Showcase Widget - Avijit
 * Description: Custom Elementor widget for responsive team showcases with AJAX filters, search, modal details, and load more.
 * Version: 1.0.0
 * Author: Avijit Dhar
 * Text Domain: ws-team-showcase-widget
 * Requires Plugins: elementor
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'WS_TSW_VERSION', '1.0.0' );
define( 'WS_TSW_FILE', __FILE__ );
define( 'WS_TSW_PATH', plugin_dir_path( __FILE__ ) );
define( 'WS_TSW_URL', plugin_dir_url( __FILE__ ) );

require_once WS_TSW_PATH . 'includes/ajax/class-ws-team-showcase-ajax.php';
require_once WS_TSW_PATH . 'includes/class-ws-team-showcase-post-types.php';

final class WS_Team_Showcase_Widget_Plugin {
	private static ?self $instance = null;

	public static function instance(): self {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	private function __construct() {
		add_action( 'plugins_loaded', [ $this, 'init' ] );
	}

	public function init(): void {
		load_plugin_textdomain( 'ws-team-showcase-widget', false, dirname( plugin_basename( __FILE__ ) ) . '/languages' );

		WS_Team_Showcase_Post_Types::register();

		if ( ! did_action( 'elementor/loaded' ) ) {
			add_action( 'admin_notices', [ $this, 'elementor_missing_notice' ] );
			return;
		}

		WS_Team_Showcase_Ajax::register();

		add_action( 'elementor/widgets/register', [ $this, 'register_widgets' ] );
		add_action( 'wp_enqueue_scripts', [ $this, 'register_assets' ] );
	}

	public function elementor_missing_notice(): void {
		if ( ! current_user_can( 'activate_plugins' ) ) {
			return;
		}

		echo '<div class="notice notice-warning"><p>';
		echo esc_html__( 'WS Team Showcase Widget requires Elementor to be installed and active.', 'ws-team-showcase-widget' );
		echo '</p></div>';
	}

	public function register_widgets( $widgets_manager ): void {
		require_once WS_TSW_PATH . 'includes/widgets/class-ws-team-showcase-widget.php';
		$widgets_manager->register( new \WS_Team_Showcase_Widget() );
	}

	public function register_assets(): void {
		$css_path = WS_TSW_PATH . 'assets/css/ws-team-showcase.css';
		$js_path  = WS_TSW_PATH . 'assets/js/ws-team-showcase.js';

		wp_register_style(
			'ws-team-showcase',
			WS_TSW_URL . 'assets/css/ws-team-showcase.css',
			[],
			file_exists( $css_path ) ? (string) filemtime( $css_path ) : WS_TSW_VERSION
		);

		wp_register_script(
			'ws-team-showcase-gsap',
			'https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.5/gsap.min.js',
			[],
			'3.12.5',
			true
		);

		wp_register_script(
			'ws-team-showcase',
			WS_TSW_URL . 'assets/js/ws-team-showcase.js',
			[ 'jquery', 'ws-team-showcase-gsap' ],
			file_exists( $js_path ) ? (string) filemtime( $js_path ) : WS_TSW_VERSION,
			true
		);

		wp_localize_script(
			'ws-team-showcase',
			'wsTeamShowcase',
			[
				'ajaxUrl' => admin_url( 'admin-ajax.php' ),
				'nonce'   => wp_create_nonce( WS_Team_Showcase_Ajax::NONCE_ACTION ),
				'i18n'    => [
					'all'       => esc_html__( 'All', 'ws-team-showcase-widget' ),
					'loadMore'  => esc_html__( 'Load More', 'ws-team-showcase-widget' ),
					'loading'   => esc_html__( 'Loading...', 'ws-team-showcase-widget' ),
					'noResults' => esc_html__( 'No team members found.', 'ws-team-showcase-widget' ),
				],
			]
		);
	}
}

WS_Team_Showcase_Widget_Plugin::instance();

register_activation_hook( __FILE__, [ 'WS_Team_Showcase_Post_Types', 'activate' ] );
register_deactivation_hook( __FILE__, [ 'WS_Team_Showcase_Post_Types', 'deactivate' ] );
